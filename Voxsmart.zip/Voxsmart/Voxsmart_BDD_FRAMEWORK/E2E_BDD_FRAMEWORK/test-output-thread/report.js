$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "403d50dd-f5b8-461d-b5cc-e739e7f6c36c",
    "feature": "Trading Feature",
    "scenario": "Select Cryptocurrencies scenario",
    "start": 1649063360374,
    "group": 1,
    "content": "",
    "tags": "@loginandselectcryptocurrencies,",
    "end": 1649063399446,
    "className": "failed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});