package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddCryptosPage {

	private WebDriver driver;

	private By tradeIcon = By.xpath("//svg[contains(@data-qa,'trade-icon')]");
	private By cryptoLnk = By.xpath("//div[@data-qa='categories__list'][contains(.,'Crypto')]");
	private By cryptoAdd1 = By.xpath("//path[contains(@fill,'currentColor')]");
	private By cryptoAdd2 = By.xpath("//svg[@data-qa='star-off-icon']");
	
	private By favoritesLnk = By.xpath("//div[@data-qa='categories__list'][contains(.,'Favorites')]");
	
	public AddCryptosPage(WebDriver driver) {

		this.driver = driver;

		PageFactory.initElements(driver, this);

	}

	public void selectTradeIcon() {
		
		  driver.findElement(tradeIcon).click(); 
	}
	
	public void selectCryptocurrencies() {
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
		driver.findElement(cryptoLnk).click();
		driver.findElement(cryptoAdd1).click();
		driver.findElement(cryptoAdd2).click();
		
	}
	
	public void favoritesTab() {
		driver.findElement(favoritesLnk).click();
		
	}
	
	public void validateSelectedCryptos() {
		
	}

}
