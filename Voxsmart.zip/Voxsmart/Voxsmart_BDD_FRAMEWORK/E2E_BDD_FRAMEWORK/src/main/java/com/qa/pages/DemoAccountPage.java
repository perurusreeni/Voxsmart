package com.qa.pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.driver.DriverFactory;

public class DemoAccountPage {

	private WebDriver driver;

	private By freeDemoLnk = By.xpath("//span[@class='text'][contains(.,'Try free demo')]");
	private By firtName = By.id("name");
	private By lastNme = By.id("lastName");
	private By emailAddr = By.id("email");
	private By phNumber = By.id("phoneInput");
	private By selectPolicyChkbox = By.xpath("(//label[@class='imglabel'])[2]");
	private By createAccountBtn = By.name("avaWidgetSubmit");
	
	

	// 2. Constructor of the page class:
	public DemoAccountPage(WebDriver driver) {

		this.driver = driver;

		PageFactory.initElements(driver, this);

	}

	// 3. page actions: features(behavior) of the page the form of methods:

	public String getLoginPageTitle() {
		return driver.getTitle();
	}

	public DemoAccountPage doLogin(String un, String pwd) {
		System.out.println("login with: " + un + " and " + pwd);
		
		driver.findElement(firtName).sendKeys(un);
		driver.findElement(lastNme).sendKeys(pwd);
		driver.findElement(emailAddr).sendKeys("abc46976@gmail.com");
		driver.findElement(phNumber).sendKeys("7775462345");
		WebElement opp1 = driver.findElement(selectPolicyChkbox);
		//opp1.isSelected();
		opp1.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(10000));
		
		  //if ( !driver.findElement(selectPolicyChkbox).isSelected() ) {
		  //driver.findElement(selectPolicyChkbox).click(); }
		 
		driver.findElement(createAccountBtn).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(1000));
		//Alert alt = driver.switchTo().alert();
		//alt.accept();
		
		return new DemoAccountPage(driver);
	}
	
	public DemoAccountPage freeDemoLink() {
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
		driver.findElement(freeDemoLnk).click();
		return new DemoAccountPage(driver);
		
	}
	

	
}
