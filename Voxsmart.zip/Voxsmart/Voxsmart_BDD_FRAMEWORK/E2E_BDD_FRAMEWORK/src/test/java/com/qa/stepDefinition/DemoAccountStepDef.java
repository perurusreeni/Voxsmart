package com.qa.stepDefinition;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.qa.driver.DriverFactory;
import com.qa.pages.DemoAccountPage;
import com.qa.utility.ConfigReader;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DemoAccountStepDef {
	
private DemoAccountPage demoAccountPage = new DemoAccountPage(DriverFactory.getDriver());

	
	@Given("user launch the url")
	public void user_launch_the_url() {
		System.out.println("Launched URL success by reading the config data");
	}

	@When("user clicks on Try Free Demo link")
	public void user_clicks_on_try_free_demo_link() {
		demoAccountPage.freeDemoLink();
	}

	
	@And("creates Demo Account by entering valid {string} and {string}")
	public void creates_demo_account_by_entering_valid(String userName, String password) {
		DriverFactory.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		demoAccountPage.doLogin(userName, password);
		
	}


}
