package com.qa.stepDefinition;

import com.qa.driver.DriverFactory;
import com.qa.pages.AddCryptosPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddCryptosStepDef {

	private AddCryptosPage addCryptosPage = new AddCryptosPage(DriverFactory.getDriver());
	
	@When("user clicks on Trade tab")
	public void user_clicks_on_trade_tab() {
		addCryptosPage.selectTradeIcon();
	}
	
	@And("I go to Crypto and select cryptocurrencies")
	public void i_go_to_crypto_and_select_cryptocurrencies() {
		addCryptosPage.selectCryptocurrencies();
		
	}
	
	@Then("I select Favorites tab")
	public void i_select_favorites_tab() {
		addCryptosPage.favoritesTab();
		
	}
	
	@Then("user shall see the selected cryptocurrencies")
	public void user_shall_see_the_selected_cryptocurrencies() {
		addCryptosPage.validateSelectedCryptos();
	}

	

}
